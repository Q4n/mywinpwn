from __future__ import absolute_import

from q4nwinlib.interactive import win
from q4nwinlib.interactive import winpwn

__all__ = ['win','winpwn']
