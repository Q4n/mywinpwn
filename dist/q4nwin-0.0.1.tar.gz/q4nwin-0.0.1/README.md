# mywinpwn

自己用的windows pwntools

env: python3/python2

## install

```bash
sudo pip install q4nwin
```

or you can find the latest version in `dist` directory

## PWN

simple lib of pwntools


## APIs

### function 

you can find them in q4nwin/toplevel.py


## refer

https://github.com/Byzero512/winpwn