# mypwn

自己用的pwntools

env: python3

## install

```bash
sudo pip install q4nwin
```

or you can find the latest version in `dist` directory

## PWN

simple lib of pwntools


## APIs

### class 

### function 


## refer

https://github.com/Byzero512/winpwn